public interface Refuelable
{
	// This program defines the Refuelable Interface
	// It contains the refuel void method
	void refuel(int litres);
}
