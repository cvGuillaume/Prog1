public abstract class RoadVehicule extends Transport
{
	// This programme defines a Cycle and is the abstract superclass of all the other road vehicule classes
	// Extension of the Transport class
	public RoadVehicule(int maxSpeed)
	{
		// Defines the maximum speed of the cycle
		super(maxSpeed);
	}
}