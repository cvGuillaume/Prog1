public class Tapir extends Herbivore
{
  Tapir(String name, int age)
  {
    super(name, age);
  }
  
  public void makeNoise()
  {
    System.out.println("Tap Tap Tap");
  }
}