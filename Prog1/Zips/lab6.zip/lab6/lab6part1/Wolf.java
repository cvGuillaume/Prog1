public class Wolf extends Animal
{
	Wolf(String name, int age) {
        super(name, age);
    }

    public void makeNoise()
    {
        System.out.print("Awuuuu");
    }
}