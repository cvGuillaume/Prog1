public class Plant extends Food
{
	Plant(String foodType) {
		super(foodType);
	}
}