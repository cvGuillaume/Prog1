public class Meat extends Food
{
	Meat(String foodType) {
		super(foodType);
	}
}