public class Parrot extends Animal
{
  Parrot(String name, int age)
  {
    super(name, age);
  }
  public void makeNoise()
  {
    System.out.println("Krrkrr");
  }
}