public abstract class Herbivore extends Animal
{
    Herbivore(String name, int age)
    {
        super(name, age);
    }
}