public abstract class Omnivore extends Animal
{
    Omnivore(String name, int age)
    {
        super(name, age);
    }
}